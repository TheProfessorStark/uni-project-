﻿using UniversityManegmentAPP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace UniversityManegmentAPP
{
    public partial class stvirayeshdars : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public SqlDataAdapter adapt2;
        public DataTable dt;
        public DataTable dt2;
        public BindingSource bs;
        public BindingSource bs2;
        public SqlCommand cmd;
        public SqlDataReader dr;
        
        public stvirayeshdars()
        {
            InitializeComponent();
            customizeDesing();
        }
       
        private void customizeDesing()
        {
            panel2.Visible = false;

        }
        private void hideSubMenu()
        {
            if (panel2.Visible == true)
                panel2.Visible = false;


        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }


        private DataRow getrow(int a)
        {
            if (a == 1)
            {
                if (bs.Current != null)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
            if(a==2)
            {
                if (bs2.Current != null)
                {
                    return ((DataRowView)bs2.Current).Row;
                }
                else
                {
                    return null;
                }
            }
            else
                return null;
        }

        public void RefreshDatagridview(string SearchText)
        {
            if (SearchText == null)
            {
                adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id='"+Class1.CurrentId+"'", sqlcon);
                adapt2 = new SqlDataAdapter("select * from TeacherSubSelected", sqlcon);

                dt = new DataTable();
                dt2 = new DataTable();

                adapt.Fill(dt);
                adapt2.Fill(dt2);
                bs = new BindingSource();
                bs2 = new BindingSource();
                bs.DataSource = dt;
                bs2.DataSource = dt2;
                dataGridView1.DataSource = bs;
                dataGridView2.DataSource = bs2;
            }
            else
            {
                adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id='" + Class1.CurrentId + "'", sqlcon);
                adapt2 = new SqlDataAdapter("select * from TeacherSubSelected where Subject_ID like'" + SearchText + "%'", sqlcon);
                dt = new DataTable();
                dt2 = new DataTable();

                adapt.Fill(dt);
                adapt2.Fill(dt2);
                bs = new BindingSource();
                bs2 = new BindingSource();
                bs.DataSource = dt;
                bs2.DataSource = dt2;
                dataGridView1.DataSource = bs;
                dataGridView2.DataSource = bs2;
            }

            if (dt.Rows.Count > 0)
            {
                dataGridView1.Visible = true;
                label1.Visible = true;
            }
              
            else
            {
                  dataGridView1.Visible = false;
                label1.Visible = false;
            }
              
           
            
            if (dt2.Rows.Count > 0)
            {
                dataGridView2.Visible = true;
                label2.Visible = true;
            }
               
            else
            {
                dataGridView2.Visible = false;
                label2.Visible = false;
            }
              
        }

        

        private void DeleteSelectedLesson_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet5.StudentSubSelected' table. You can move, or remove it, as needed.
            //this.studentSubSelectedTableAdapter.Fill(this.uniWebDataSet5.StudentSubSelected);
            // TODO: This line of code loads data into the 'uniWebDataSet4.SubPresented' table. You can move, or remove it, as needed.
            this.subPresentedTableAdapter.Fill(this.uniWebDataSet4.SubPresented);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            RefreshDatagridview(null);
            dataGridView2.Visible= false;
            label2.Visible = false;
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == "جستجو : کد درس")
                txtSearch.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "جستجو : کد درس";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txtSearch.Text);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            if (resualt == DialogResult.OK)
            {
                DataRow crow = getrow(1);
                SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                adapt = sqlb.DataAdapter;
                crow.Delete();
                adapt.Update(dt);
                dt.AcceptChanges();
                RefreshDatagridview(null);
            }
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            DataRow crow = getrow(2);
            DataRow newrow = dt.NewRow();

            newrow["Student_Id"] = Class1.CurrentId;
            newrow["Subject_Id"] = crow["Subject_ID"].ToString();
            newrow["Subject_Name"] = crow["Subject_Name"].ToString();
            newrow["subject_Unit"] = crow["Subject_Unit"].ToString();
            newrow["Subject_Teacher"] = crow["Teacher_Presentation"].ToString();
            newrow["Sub_Present_ID"] = crow["Present_ID"].ToString();
            newrow["Teacher_Present_ID"] = crow["Teacher_Present_ID"].ToString();
            newrow["NV"] = Class1.CurrentId + "/" + crow["Subject_ID"].ToString();

            cmd = new SqlCommand("select * from StudentSubSelected where NV='" + Class1.CurrentId + "/" + crow["Subject_ID"].ToString() + "'", sqlcon);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("مرض داری 2 بار اد می کنی؟", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dr.Close();
            }
            else
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    dr.Close();
                    dt.Rows.Add(newrow);

                    SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                    adapt.Update(dt);
                    dt.AcceptChanges();

                    RefreshDatagridview(null);
                }
                else if (resualt == DialogResult.Cancel)
                {
                    txtSearch.Text = "";
                }
            }
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (dataGridView2.Visible == false)
            {
                dataGridView2.Visible = true;
                label2.Visible = true;
            }
            else
            {
                dataGridView2.Visible = false;
                label2.Visible = false;
            }
            if (panel2.Visible == true)
                panel2.Visible = false;
            else
                panel2.Visible = true;
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back )
            {
                e.Handled = false;      
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
