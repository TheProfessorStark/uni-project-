using UniversityManegmentAPP;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace UniversityManegmentAPP
{
    public partial class studentmain : Form
    {
        public Button currentcolor;
        public studentmain()
        {
            InitializeComponent();
            customizeDesing();
        }
        private void customizeDesing()
        {
            paneld1.Visible = false;
            paneld2.Visible = false;
            paneld4.Visible = false;
        }
        private void hideSubMenu()
        {
            if (paneld1.Visible == true)
                paneld1.Visible = false;
            if (paneld2.Visible == true)
                paneld2.Visible = false;
            if (paneld4.Visible == true)
                paneld4.Visible = false;

        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }
        //...btn_code
        public Button currentbuttoncolor(Button currentbutton)
        {
            if (currentcolor != null)
                currentcolor.BackColor = Color.FromArgb(15, 32, 39);
            currentcolor = currentbutton;
            currentcolor.BackColor = Color.DarkCyan;
            return null;
        }


        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
                activeform.Close();
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelcontainer.Controls.Add(childform);
            panelcontainer.Tag = childform;
            childform.BringToFront();
            childform.Show();
            childform.Size = new Size(1088, 641);
          //  panel1.Visible = false;
            pictureBox2.BringToFront();

        }

        private void btn_addsub_Click(object sender, EventArgs e)
        {
            openchildform(new stvirayeshdars());
            currentbuttoncolor((Button)sender);

        }


        private void btnd_editsub_Click(object sender, EventArgs e)
        {
            showSubMenu(paneld1);
        }

        private void btn_editp_Click(object sender, EventArgs e)
        {
            showSubMenu(paneld4);
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            if (panel1.Visible == true)
                panel1.Visible = false;
            else
                panel1.Visible = true;
        }

        private void btnd4_Click(object sender, EventArgs e)
        {
            openchildform(new karnameds());
            currentbuttoncolor((Button)sender);
        }

        private void panelcontainer_Paint(object sender, PaintEventArgs e)
        {


        }

        private void mainhead_Load(object sender, EventArgs e)
        {

        }

       
    }
}