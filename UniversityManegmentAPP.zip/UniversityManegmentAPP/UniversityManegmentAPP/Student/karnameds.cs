﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UniversityManegmentAPP
{
    public partial class karnameds : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        public SqlCommand cmd;
        public SqlDataReader dr;

        public karnameds()
        {
            InitializeComponent();

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet8.StudentSubSelected' table. You can move, or remove it, as needed.
            this.studentSubSelectedTableAdapter.Fill(this.uniWebDataSet8.StudentSubSelected);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            RefreshDatagridview();
            cmd = new SqlCommand("select * from StudentInfo where ID='" + Class1.CurrentId + "'", sqlcon);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                lblID.Text = dr["ID"].ToString();
                lblName.Text = dr["First_Name"].ToString();
                lblFamily.Text = dr["Last_Name"].ToString();
                lblFathern.Text = dr["Father_Name"].ToString();
                lblNCode.Text = dr["National_Code"].ToString();
                lblBdate.Text = dr["Birth_Date"].ToString();
                lblEdate.Text = dr["Entrance_Date"].ToString();
                lblMajor.Text = dr["Major"].ToString();
                lblGrade.Text = dr["Grade"].ToString();
                lblPhoneNumber.Text = dr["Phone_Number"].ToString();
                dr.Close();
            }
            else
                MessageBox.Show("error");

        }

        public void RefreshDatagridview()
        {

            adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id='" + Class1.CurrentId + "'", sqlcon);
            dt = new DataTable();
            adapt.Fill(dt);
            bs = new BindingSource();
            bs.DataSource = dt;
            dataGridView1.DataSource = bs;
            if (dt.Rows.Count > 0)
            {
                dataGridView1.Visible = true;
                int sumu = 0;
                double sump = 0;
                int T = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    try
                    {
                        if (Convert.ToDouble(dt.Rows[i][5]) > 0)
                        {
                            sump += Convert.ToDouble(dt.Rows[i][5]);
                            T++;
                        }
                    }
                    catch { }

                    try
                    {
                        sumu += Convert.ToInt32(dt.Rows[i][3]);
                    }
                    catch { }

                }
                lblunitshow.Text = sumu.ToString();
                lblpoint.Text=(sump/T).ToString();
            }
            else
                dataGridView1.Visible = false;
        }
    }
}