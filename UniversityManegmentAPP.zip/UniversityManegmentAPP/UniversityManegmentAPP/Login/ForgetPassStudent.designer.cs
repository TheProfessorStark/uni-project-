﻿namespace UniversityManegmentAPP
{
    partial class ForgetPassStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ForgetPassStudent));
            this.btnRecord = new System.Windows.Forms.Button();
            this.txtNCodeForget = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsernameForget = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.panelu1 = new System.Windows.Forms.Panel();
            this.txtnewpass = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelu1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRecord
            // 
            this.btnRecord.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRecord.BackColor = System.Drawing.Color.Transparent;
            this.btnRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRecord.Font = new System.Drawing.Font("B Narm", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnRecord.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRecord.Location = new System.Drawing.Point(15, 227);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(110, 43);
            this.btnRecord.TabIndex = 3;
            this.btnRecord.Text = "ثبت";
            this.btnRecord.UseVisualStyleBackColor = false;
            this.btnRecord.Click += new System.EventHandler(this.btnRecord_Click);
            // 
            // txtNCodeForget
            // 
            this.txtNCodeForget.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNCodeForget.Font = new System.Drawing.Font("B Narm", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtNCodeForget.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.txtNCodeForget.Location = new System.Drawing.Point(368, 117);
            this.txtNCodeForget.MaxLength = 13;
            this.txtNCodeForget.Name = "txtNCodeForget";
            this.txtNCodeForget.Size = new System.Drawing.Size(269, 38);
            this.txtNCodeForget.TabIndex = 2;
            this.txtNCodeForget.Text = ":کد ملی";
            this.txtNCodeForget.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNCodeForget.Click += new System.EventHandler(this.txtNCodeForget_Click);
            this.txtNCodeForget.TextChanged += new System.EventHandler(this.txtNationalCode_TextChanged);
            this.txtNCodeForget.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNCodeForget_KeyPress);
            this.txtNCodeForget.Leave += new System.EventHandler(this.txtNCodeForget_Leave);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("B Narm", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(531, 72);
            this.label1.MinimumSize = new System.Drawing.Size(124, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 31);
            this.label1.TabIndex = 8;
            this.label1.Text = ": پسورد جدید";
            this.label1.Click += new System.EventHandler(this.lblRecoveryPassHead_Click);
            // 
            // txtUsernameForget
            // 
            this.txtUsernameForget.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUsernameForget.Font = new System.Drawing.Font("B Narm", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtUsernameForget.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.txtUsernameForget.Location = new System.Drawing.Point(368, 64);
            this.txtUsernameForget.MaxLength = 13;
            this.txtUsernameForget.Name = "txtUsernameForget";
            this.txtUsernameForget.Size = new System.Drawing.Size(269, 38);
            this.txtUsernameForget.TabIndex = 1;
            this.txtUsernameForget.Text = ": کد دانشجویی";
            this.txtUsernameForget.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUsernameForget.Click += new System.EventHandler(this.txtUsernameForget_Click);
            this.txtUsernameForget.TextChanged += new System.EventHandler(this.txtNationalCode_TextChanged);
            this.txtUsernameForget.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsernameForget_KeyPress);
            this.txtUsernameForget.Leave += new System.EventHandler(this.txtUsernameForget_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panel1.Controls.Add(this.txtUsernameForget);
            this.panel1.Controls.Add(this.txtNCodeForget);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(668, 336);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(29, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 264);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panel2.Controls.Add(this.btnReturn);
            this.panel2.Controls.Add(this.btnRecord);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(668, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(135, 336);
            this.panel2.TabIndex = 11;
            // 
            // btnReturn
            // 
            this.btnReturn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.Font = new System.Drawing.Font("B Narm", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnReturn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReturn.Location = new System.Drawing.Point(15, 276);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(110, 43);
            this.btnReturn.TabIndex = 0;
            this.btnReturn.Text = "بازگشت";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // panelu1
            // 
            this.panelu1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panelu1.Controls.Add(this.txtnewpass);
            this.panelu1.Controls.Add(this.label1);
            this.panelu1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelu1.Location = new System.Drawing.Point(0, 336);
            this.panelu1.Margin = new System.Windows.Forms.Padding(2);
            this.panelu1.Name = "panelu1";
            this.panelu1.Size = new System.Drawing.Size(803, 164);
            this.panelu1.TabIndex = 12;
            // 
            // txtnewpass
            // 
            this.txtnewpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.txtnewpass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtnewpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewpass.ForeColor = System.Drawing.Color.White;
            this.txtnewpass.Location = new System.Drawing.Point(258, 70);
            this.txtnewpass.Multiline = true;
            this.txtnewpass.Name = "txtnewpass";
            this.txtnewpass.ReadOnly = true;
            this.txtnewpass.Size = new System.Drawing.Size(269, 35);
            this.txtnewpass.TabIndex = 9;
            this.txtnewpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ForgetPassStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 500);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelu1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(823, 545);
            this.MinimumSize = new System.Drawing.Size(384, 222);
            this.Name = "ForgetPassStudent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "رمز عبور را فراموش کرده اید؟";
            this.Load += new System.EventHandler(this.ForgetPassHead_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panelu1.ResumeLayout(false);
            this.panelu1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.TextBox txtNCodeForget;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsernameForget;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelu1;
        private System.Windows.Forms.TextBox txtnewpass;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}