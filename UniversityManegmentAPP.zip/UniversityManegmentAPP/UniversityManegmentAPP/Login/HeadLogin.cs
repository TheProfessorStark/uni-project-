﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UniversityManegmentAPP;

namespace UniversityManegmentAPP
{
    public partial class HeadLogin : Form
    {
        public SqlConnection sqlcon;
        public SqlDataReader dr;
        public SqlCommand com;

        public HeadLogin()
        {
            InitializeComponent();
        }

        private void ProfessorLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Restart();
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtPassword_Click(sender, e);
                    txtPassword.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnEnter_Click(sender, e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtUsername_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == ": نام کاربری")
                txtUsername.Text = null;
        }

        private void txtPassword_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == ":رمز عبور")
            {
                txtPassword.Text = null;
            }
        }

        private void txtUsername_Leave(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsername.Text = ": نام کاربری";
            }
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "")
                txtPassword.Text = ":رمز عبور";
            if (checkBox1.Checked == false && txtPassword.UseSystemPasswordChar == true && txtPassword.Text == ":رمز عبور")
                txtPassword.UseSystemPasswordChar = false;
            else if (checkBox1.Checked == true && txtPassword.Text == ":رمز عبور")
                txtPassword.Text = ":رمز عبور";
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text != "" && txtPassword.Text != "")
            {
                if (txtUsername.Text != ": نام کاربری" && txtPassword.Text != ":رمز عبور")
                {
                    sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
                    sqlcon.Open();
                    com = new SqlCommand("select * from HeadInfo where ID='" + txtUsername.Text + "'and Password='" + txtPassword.Text + "'", sqlcon);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        dr.Close();
                        this.Hide();
                        this.Close();
                        new mainhead().ShowDialog();
                    }
                    else
                    {
                        DialogResult dr = MessageBox.Show("اطلاعاتت رو مثل ادم وارد کن...", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        if (dr == DialogResult.OK)
                        {
							txtUsername.Text = ": نام کاربری";
							txtPassword.Text = ":رمز عبور";
							txtPassword.UseSystemPasswordChar = false;
							txtUsername.Select();
						}
                        sqlcon.Close();
                    }
                }
                else
                {
                    MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو", "اخطار", MessageBoxButtons.OK);
					txtUsername.Text = ": نام کاربری";
					txtPassword.Text = ":رمز عبور";
					txtUsername.Select();
				}
            }
            else
            {
                MessageBox.Show("خداییش من الان چه کنم؟؟ ناموسا درست وارد کن اطلاعات رو", "اخطار", MessageBoxButtons.OK);
				txtUsername.Text = ": نام کاربری";
				txtPassword.Text = ":رمز عبور";
				txtUsername.Select();
			}
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false && txtPassword.Text != ":رمز عبور")
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else if (checkBox1.Checked == true && txtPassword.Text != ":رمز عبور")
                txtPassword.UseSystemPasswordChar = false;
        }

        private void btnForgetPassword_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
            new ForgetPassHead().ShowDialog();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

		private void HeadLogin_Load(object sender, EventArgs e)
		{
            txtUsername.Select();
		}
	}
}
