﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityManegmentAPP
{
    public partial class ForgetPassProfessor : Form
    {
        Random rand = new Random();
        public SqlConnection sqlcon;
        public SqlDataAdapter adapter;
        public SqlDataReader dr;
        public SqlCommandBuilder sqlb;
        public SqlCommand cmd;
        public bool condition = false;


        public ForgetPassProfessor()
        {
            InitializeComponent();
            customizeDesing();
        }

        private void customizeDesing()
        {
            panelu1.Visible = false;
        }

        private void txtUsernameForget_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtNCodeForget_Click(sender, e);
                    txtNCodeForget.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtNCodeForget_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnRecord_Click_1(sender, e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtUsernameForget_Click(object sender, EventArgs e)
        {
            if (txtUsernameForget.Text == ": کد پرسنلی")
            {
                txtUsernameForget.Text = null;
            }
        }

        private void txtNCodeForget_Click(object sender, EventArgs e)
        {
            if (txtNCodeForget.Text == ":کد ملی")
            {
                txtNCodeForget.Text = null;
            }
        }

        private void txtUsernameForget_Leave(object sender, EventArgs e)
        {
            if (txtUsernameForget.Text == "")
            {
                txtUsernameForget.Text = ": کد پرسنلی";
            }
        }

        private void txtNCodeForget_Leave(object sender, EventArgs e)
        {
            if (txtNCodeForget.Text == "")
            {
                txtNCodeForget.Text = ":کد ملی";

            }
        }

        private void hideSubMenu()
        {
            if (panelu1.Visible == true)
                panelu1.Visible = false;
        }

        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }

        private void btnRecord_Click_1(object sender, EventArgs e)
        {
            if (txtUsernameForget.Text != "" && txtNCodeForget.Text != "" && txtUsernameForget.Text != ":نام کاربری" && txtNCodeForget.Text != ":کد ملی")
            {
                if (condition == false)
                {
                    rand = new Random();

                    int password = rand.Next(1000, 9999);

                    sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
                    sqlcon.Open();
                    cmd = new SqlCommand("select * from MastersInfo where Personal_Id ='" + txtUsernameForget.Text + "'and National_Code='" + txtNCodeForget.Text + "'", sqlcon);
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        dr.Close();
                        SqlCommand cmd = new SqlCommand("update MastersInfo set Password ='" + password + "'where Personal_Id ='" + txtUsernameForget.Text + "'", sqlcon);
                        cmd.ExecuteNonQuery();
                        panelu1.Visible = true;
                        txtnewpass.Text = password.ToString();
                        condition = true;
                    }
                    else
                    {
                        MessageBox.Show("اطلاعاتت رو مثل ادم وارد کن ...", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtUsernameForget.Text = ": کد پرسنلی";
                        txtNCodeForget.Text = ":کد ملی";
                    }
                }
                else
                {
                    MessageBox.Show("خوب چند بار میخوای رمزتو عوض کنی ... ؟؟", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
