﻿using UniversityManegmentAPP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UniversityManegmentAPP
{
    public partial class Professorlesonselect2 : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public SqlDataAdapter adapt2;
        public DataTable dt;
        public DataTable dt2;
        public BindingSource bs;
        public BindingSource bs2;
        public SqlCommand cmd;
        public SqlDataReader dr;
       
        public Professorlesonselect2()
        {
            InitializeComponent();
            customizeDesing();

        }
        private void customizeDesing()
        {
            panelb.Visible = false;
            panelu.Visible = false;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (panelu.Visible == false)
                panelu.Visible = true;
            else
                panelu.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (panelb.Visible == false)
                panelb.Visible = true;
            else
                panelb.Visible = false;
            if (dataGridView2.Visible == false)
            {
                dataGridView2.Visible = true;
                label2.Visible = true;
            }
            else
            {
                dataGridView2.Visible = false;
                label2.Visible = false;
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet3.TeacherSubSelected' table. You can move, or remove it, as needed.
            this.teacherSubSelectedTableAdapter.Fill(this.uniWebDataSet3.TeacherSubSelected);
            // TODO: This line of code loads data into the 'uniWebDataSet2.SubPresented' table. You can move, or remove it, as needed.
            this.subPresentedTableAdapter.Fill(this.uniWebDataSet2.SubPresented);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            RefreshDatagridview(null);
            dataGridView2.Visible = false;
            label2.Visible = false;
        }

        private DataRow getrow(int a)
        {
            if (a == 1)
            {
                if (bs.Current != null)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
            if (a == 2)
            {
                if (bs2.Current != null)
                {
                    return ((DataRowView)bs2.Current).Row;
                }
                else
                {
                    return null;
                }
            }
            else
                return null;
        }

        public void RefreshDatagridview(string SearchText)
        {
            if (SearchText == null)
            {
                adapt = new SqlDataAdapter("select * from TeacherSubSelected where Teacher_Present_ID='" + Class1.CurrentId+"'", sqlcon);
                adapt2 = new SqlDataAdapter("select * from SubPresented", sqlcon);

                dt = new DataTable();
                dt2 = new DataTable();

                adapt.Fill(dt);
                adapt2.Fill(dt2);
                bs = new BindingSource();
                bs2 = new BindingSource();
                bs.DataSource = dt;
                bs2.DataSource = dt2;
                dataGridView1.DataSource = bs;
                dataGridView2.DataSource = bs2;
            }
            else
            {
                adapt = new SqlDataAdapter("select * from TeacherSubSelected where Teacher_Present_ID = '" + Class1.CurrentId+"'", sqlcon);
                adapt2 = new SqlDataAdapter("select * from SubPresented where Subject_ID like'" + SearchText + "%'", sqlcon);
                dt = new DataTable();
                dt2 = new DataTable();

                adapt.Fill(dt);
                adapt2.Fill(dt2);
                bs = new BindingSource();
                bs2 = new BindingSource();
                bs.DataSource = dt;
                bs2.DataSource = dt2;
                dataGridView1.DataSource = bs;
                dataGridView2.DataSource = bs2;
            }

            if (dt.Rows.Count > 0)
            {
                dataGridView1.Visible = true;
                label1.Visible = true;
            }

            else
            {
                dataGridView1.Visible = false;
                label1.Visible = false;
            }



            if (dt2.Rows.Count > 0)
            {
                dataGridView2.Visible = true;
                label2.Visible = true;
            }

            else
            {
                dataGridView2.Visible = false;
                label2.Visible = false;
            }

        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == "جستجو : کد درس")
                txtSearch.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "جستجو : کد درس";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txtSearch.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            if (resualt == DialogResult.OK)
            {
                DataRow crow = getrow(2);
                DataRow newrow = dt.NewRow();

                newrow["Subject_Id"] = crow["Subject_ID"].ToString();
                newrow["Subject_Name"] = crow["Subject_Name"].ToString();
                newrow["Subject_Unit"] = crow["Subject_Unit"].ToString();
                newrow["ClassStart_Date"] = crow["ClassStart_Date"].ToString();
                newrow["Exam_Date"] = crow["Exam_Date"].ToString();
                newrow["Day_Presentation"] = crow["Day_Presentation"].ToString();
                newrow["Hour_Presentation"] = crow["Hour_Presentation"].ToString();
                newrow["Teacher_Presentation"] = Class1.CurrentName;
                newrow["Teacher_Present_ID"] = Class1.CurrentId;
                newrow["Present_ID"] = crow["Sub_Present_ID"].ToString();

                cmd = new SqlCommand("select * from TeacherSubSelected where Present_ID='" + crow["Sub_Present_ID"].ToString() + "'", sqlcon);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("مرض داری 2 بار اد می کنی؟", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dr.Close();
                }
                else
                {
                    dr.Close();
                    dt.Rows.Add(newrow);

                    SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                    adapt.Update(dt);
                    dt.AcceptChanges();
                    RefreshDatagridview(null);

                }
            }
            else if (resualt == DialogResult.Cancel)
            {
                txtSearch.Text = "جستجو : کد درس";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
			DataRow crow = getrow(1);
			if (crow != null)
            {
                    DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)                                      
                {
                    SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                    adapt = sqlb.DataAdapter;
                    crow.Delete();
                    adapt.Update(dt);
                    dt.AcceptChanges();
                    RefreshDatagridview(null);

                }
            }				
                else
                    MessageBox.Show("درسی برای حذف کردن وجود ندارد","اخطار",MessageBoxButtons.OK);
                              
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back )
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}

