﻿using System.Windows.Forms;

namespace UniversityManegmentAPP
{
    partial class mainhead
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainhead));
            this.panel1 = new System.Windows.Forms.Panel();
            this.paneld4 = new System.Windows.Forms.Panel();
            this.btnd4 = new System.Windows.Forms.Button();
            this.btn_editp = new System.Windows.Forms.Button();
            this.paneld2 = new System.Windows.Forms.Panel();
            this.btnkarname = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btn_editstudent = new System.Windows.Forms.Button();
            this.paneld1 = new System.Windows.Forms.Panel();
            this.btn_editSsub = new System.Windows.Forms.Button();
            this.btn_editpsub = new System.Windows.Forms.Button();
            this.btn_addsub = new System.Windows.Forms.Button();
            this.btnd_editsub = new System.Windows.Forms.Button();
            this.panelcontainer = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.paneld4.SuspendLayout();
            this.paneld2.SuspendLayout();
            this.paneld1.SuspendLayout();
            this.panelcontainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panel1.Controls.Add(this.paneld4);
            this.panel1.Controls.Add(this.btn_editp);
            this.panel1.Controls.Add(this.paneld2);
            this.panel1.Controls.Add(this.btn_editstudent);
            this.panel1.Controls.Add(this.paneld1);
            this.panel1.Controls.Add(this.btnd_editsub);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 25, 0, 0);
            this.panel1.Size = new System.Drawing.Size(213, 523);
            this.panel1.TabIndex = 0;
            // 
            // paneld4
            // 
            this.paneld4.AutoSize = true;
            this.paneld4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.paneld4.Controls.Add(this.btnd4);
            this.paneld4.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneld4.Location = new System.Drawing.Point(0, 388);
            this.paneld4.Margin = new System.Windows.Forms.Padding(2);
            this.paneld4.Name = "paneld4";
            this.paneld4.Size = new System.Drawing.Size(213, 36);
            this.paneld4.TabIndex = 7;
            this.paneld4.Visible = false;
            // 
            // btnd4
            // 
            this.btnd4.AutoSize = true;
            this.btnd4.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnd4.FlatAppearance.BorderSize = 0;
            this.btnd4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BlueViolet;
            this.btnd4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnd4.Font = new System.Drawing.Font("B Narm", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnd4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnd4.Location = new System.Drawing.Point(0, 0);
            this.btnd4.Margin = new System.Windows.Forms.Padding(2);
            this.btnd4.Name = "btnd4";
            this.btnd4.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnd4.Size = new System.Drawing.Size(213, 36);
            this.btnd4.TabIndex = 6;
            this.btnd4.Text = "افزودن استاد";
            this.btnd4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnd4.UseVisualStyleBackColor = true;
            this.btnd4.Click += new System.EventHandler(this.btnd4_Click);
            // 
            // btn_editp
            // 
            this.btn_editp.AutoSize = true;
            this.btn_editp.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_editp.FlatAppearance.BorderSize = 0;
            this.btn_editp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BlueViolet;
            this.btn_editp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editp.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_editp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_editp.Location = new System.Drawing.Point(0, 327);
            this.btn_editp.Margin = new System.Windows.Forms.Padding(5);
            this.btn_editp.Name = "btn_editp";
            this.btn_editp.Padding = new System.Windows.Forms.Padding(10);
            this.btn_editp.Size = new System.Drawing.Size(213, 61);
            this.btn_editp.TabIndex = 5;
            this.btn_editp.Text = "ویرایش اساتید";
            this.btn_editp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_editp.UseVisualStyleBackColor = true;
            this.btn_editp.Click += new System.EventHandler(this.btn_editp_Click);
            // 
            // paneld2
            // 
            this.paneld2.AutoSize = true;
            this.paneld2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.paneld2.Controls.Add(this.btnkarname);
            this.paneld2.Controls.Add(this.button8);
            this.paneld2.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneld2.Location = new System.Drawing.Point(0, 255);
            this.paneld2.Margin = new System.Windows.Forms.Padding(2);
            this.paneld2.Name = "paneld2";
            this.paneld2.Size = new System.Drawing.Size(213, 72);
            this.paneld2.TabIndex = 4;
            // 
            // btnkarname
            // 
            this.btnkarname.AutoSize = true;
            this.btnkarname.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnkarname.FlatAppearance.BorderSize = 0;
            this.btnkarname.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnkarname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkarname.Font = new System.Drawing.Font("B Narm", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnkarname.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnkarname.Location = new System.Drawing.Point(0, 36);
            this.btnkarname.Margin = new System.Windows.Forms.Padding(2);
            this.btnkarname.Name = "btnkarname";
            this.btnkarname.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnkarname.Size = new System.Drawing.Size(213, 36);
            this.btnkarname.TabIndex = 2;
            this.btnkarname.Text = "کارنامه دانشجویان";
            this.btnkarname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnkarname.UseVisualStyleBackColor = true;
            this.btnkarname.Click += new System.EventHandler(this.btnkarname_Click);
            // 
            // button8
            // 
            this.button8.AutoSize = true;
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("B Narm", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button8.Location = new System.Drawing.Point(0, 0);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.button8.Size = new System.Drawing.Size(213, 36);
            this.button8.TabIndex = 1;
            this.button8.Text = "ویرایش لیست دانشجویان";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btn_editstudent
            // 
            this.btn_editstudent.AutoSize = true;
            this.btn_editstudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_editstudent.FlatAppearance.BorderSize = 0;
            this.btn_editstudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BlueViolet;
            this.btn_editstudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editstudent.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_editstudent.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_editstudent.Location = new System.Drawing.Point(0, 194);
            this.btn_editstudent.Margin = new System.Windows.Forms.Padding(5);
            this.btn_editstudent.Name = "btn_editstudent";
            this.btn_editstudent.Padding = new System.Windows.Forms.Padding(10);
            this.btn_editstudent.Size = new System.Drawing.Size(213, 61);
            this.btn_editstudent.TabIndex = 3;
            this.btn_editstudent.Text = "مدیریت دانشجویان";
            this.btn_editstudent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_editstudent.UseVisualStyleBackColor = true;
            this.btn_editstudent.Click += new System.EventHandler(this.btn_editstudent_Click);
            // 
            // paneld1
            // 
            this.paneld1.AutoSize = true;
            this.paneld1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.paneld1.Controls.Add(this.btn_editSsub);
            this.paneld1.Controls.Add(this.btn_editpsub);
            this.paneld1.Controls.Add(this.btn_addsub);
            this.paneld1.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneld1.Location = new System.Drawing.Point(0, 86);
            this.paneld1.Margin = new System.Windows.Forms.Padding(2);
            this.paneld1.Name = "paneld1";
            this.paneld1.Size = new System.Drawing.Size(213, 108);
            this.paneld1.TabIndex = 2;
            // 
            // btn_editSsub
            // 
            this.btn_editSsub.AutoSize = true;
            this.btn_editSsub.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_editSsub.FlatAppearance.BorderSize = 0;
            this.btn_editSsub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_editSsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editSsub.Font = new System.Drawing.Font("B Narm", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_editSsub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_editSsub.Location = new System.Drawing.Point(0, 72);
            this.btn_editSsub.Margin = new System.Windows.Forms.Padding(5);
            this.btn_editSsub.Name = "btn_editSsub";
            this.btn_editSsub.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btn_editSsub.Size = new System.Drawing.Size(213, 36);
            this.btn_editSsub.TabIndex = 2;
            this.btn_editSsub.Text = "ویرایش دروس دانشجو";
            this.btn_editSsub.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_editSsub.UseVisualStyleBackColor = true;
            this.btn_editSsub.Click += new System.EventHandler(this.btn_editSsub_Click);
            // 
            // btn_editpsub
            // 
            this.btn_editpsub.AutoSize = true;
            this.btn_editpsub.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_editpsub.FlatAppearance.BorderSize = 0;
            this.btn_editpsub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_editpsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editpsub.Font = new System.Drawing.Font("B Narm", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_editpsub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_editpsub.Location = new System.Drawing.Point(0, 36);
            this.btn_editpsub.Margin = new System.Windows.Forms.Padding(5);
            this.btn_editpsub.Name = "btn_editpsub";
            this.btn_editpsub.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btn_editpsub.Size = new System.Drawing.Size(213, 36);
            this.btn_editpsub.TabIndex = 1;
            this.btn_editpsub.Text = "افزودن و ویرایش دروس ارائه شده";
            this.btn_editpsub.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_editpsub.UseVisualStyleBackColor = true;
            this.btn_editpsub.Click += new System.EventHandler(this.btn_editpsub_Click);
            // 
            // btn_addsub
            // 
            this.btn_addsub.AutoSize = true;
            this.btn_addsub.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_addsub.FlatAppearance.BorderSize = 0;
            this.btn_addsub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_addsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_addsub.Font = new System.Drawing.Font("B Narm", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_addsub.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_addsub.Location = new System.Drawing.Point(0, 0);
            this.btn_addsub.Margin = new System.Windows.Forms.Padding(5);
            this.btn_addsub.Name = "btn_addsub";
            this.btn_addsub.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btn_addsub.Size = new System.Drawing.Size(213, 36);
            this.btn_addsub.TabIndex = 0;
            this.btn_addsub.Text = "افزودن و ویرایش دروس جدید";
            this.btn_addsub.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_addsub.UseVisualStyleBackColor = true;
            this.btn_addsub.Click += new System.EventHandler(this.btn_addsub_Click);
            // 
            // btnd_editsub
            // 
            this.btnd_editsub.AutoSize = true;
            this.btnd_editsub.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnd_editsub.FlatAppearance.BorderSize = 0;
            this.btnd_editsub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BlueViolet;
            this.btnd_editsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnd_editsub.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnd_editsub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnd_editsub.Location = new System.Drawing.Point(0, 25);
            this.btnd_editsub.Margin = new System.Windows.Forms.Padding(5);
            this.btnd_editsub.Name = "btnd_editsub";
            this.btnd_editsub.Padding = new System.Windows.Forms.Padding(10);
            this.btnd_editsub.Size = new System.Drawing.Size(213, 61);
            this.btnd_editsub.TabIndex = 1;
            this.btnd_editsub.Text = "مدیریت دروس";
            this.btnd_editsub.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnd_editsub.UseVisualStyleBackColor = true;
            this.btnd_editsub.Click += new System.EventHandler(this.btnd_editsub_Click);
            // 
            // panelcontainer
            // 
            this.panelcontainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panelcontainer.Controls.Add(this.pictureBox2);
            this.panelcontainer.Controls.Add(this.pictureBox1);
            this.panelcontainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelcontainer.Location = new System.Drawing.Point(213, 0);
            this.panelcontainer.Margin = new System.Windows.Forms.Padding(2);
            this.panelcontainer.Name = "panelcontainer";
            this.panelcontainer.Size = new System.Drawing.Size(712, 523);
            this.panelcontainer.TabIndex = 2;
            this.panelcontainer.Paint += new System.Windows.Forms.PaintEventHandler(this.panelcontainer_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-4, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(29, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(208, 103);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // mainhead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 523);
            this.Controls.Add(this.panelcontainer);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(941, 561);
            this.Name = "mainhead";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "صفحه مدیر گروه";
            this.Load += new System.EventHandler(this.mainhead_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.paneld4.ResumeLayout(false);
            this.paneld4.PerformLayout();
            this.paneld2.ResumeLayout(false);
            this.paneld2.PerformLayout();
            this.paneld1.ResumeLayout(false);
            this.paneld1.PerformLayout();
            this.panelcontainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel paneld1;
        private Button btn_editSsub;
        private Button btn_editpsub;
        private Button btn_addsub;
        private Button btnd_editsub;
        private Button btnd4;
        private Button btn_editp;
        private Panel paneld2;
        private Button btnkarname;
        private Button button8;
        private Button btn_editstudent;
        private Panel panelcontainer;
        private Panel panel4;
        private Button button10;
        private Button button1;
        private Panel paneld4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
    }
}