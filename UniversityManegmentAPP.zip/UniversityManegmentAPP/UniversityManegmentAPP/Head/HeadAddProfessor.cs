﻿using DevComponents.Schedule.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityManegmentAPP
{
    public partial class HeadAddProfessor : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        public SqlCommand cmd;
        public SqlDataReader dr;
        public bool edit = false;
        string date;

        public HeadAddProfessor()
        {
            InitializeComponent();
        }

        private void txtName_Click(object sender, EventArgs e) { }
        private void txtLastName_Click(object sender, EventArgs e) { }
        private void txtNationalCode_Click(object sender, EventArgs e) { }
        private void txtFatherName_Click(object sender, EventArgs e) { }
        private void txtBirthDate_Click(object sender, EventArgs e) { }
        private void txtGrade_Click(object sender, EventArgs e) { }
        private void txtPhoneNum_Click(object sender, EventArgs e) { }
        private void txtPassword_Click(object sender, EventArgs e) { }
        private void txtEnterYear_Click(object sender, EventArgs e) { }
        private void txtAddress_Click(object sender, EventArgs e) { }

        private void txtPersonalId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtName_Click(sender, e);
                    txtName.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }
        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar==(char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtLastName_Click(sender, e);
                    txtLastName.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtNationalCode_Click(sender, e);
                    txtNationalCode.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtNationalCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtFatherName_Click(sender, e);
                    txtFatherName.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtFatherName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {

                    numericUpDownyear.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }


        private void txtGrade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtPhoneNum_Click(sender, e);
                    txtPhoneNum.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPhoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtPassword_Click(sender, e);
                    txtPassword.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtAddress_Click(sender, e);
                    txtAddress.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }


        private void txtAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    pictureBox3_Click(sender, e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }


        public void RefreshDatagridview(string SearchText)
        {
            if (SearchText == null)
            {
                adapt = new SqlDataAdapter("select * from MastersInfo", sqlcon);

                dt = new DataTable();

                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }
            else
            {
                adapt = new SqlDataAdapter("select * from MastersInfo where Personal_Id like'" + SearchText + "%'", sqlcon);
                dt = new DataTable();

                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }

            if (dt.Rows.Count > 0)
                dataGridView1.Visible = true;
            else
                dataGridView1.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (txtPersonalId.Text != "" && txtName.Text.Trim() != "" && txtLastName.Text.Trim() != "" && txtNationalCode.Text != "" && txtFatherName.Text.Trim() != "" && 
                 txtPhoneNum.Text != "" && txtPassword.Text != "" && txtAddress.Text.Trim() != "")
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    if (edit == false)
                    {
                        DataRow newrow = dt.NewRow();
                        newrow["Personal_Id"] = txtPersonalId.Text;
                        newrow["First_Name"] = txtName.Text.TrimEnd().TrimStart();
                        newrow["Last_Name"] = txtLastName.Text.TrimEnd().TrimStart();
                        newrow["Degree_Education"] = comboBoxEx1.Text;
                        string day, month;
                        if (numericUpDownday.Value < 10)
                            day = '0' + numericUpDownday.Value.ToString();
                        else
                            day = numericUpDownday.Value.ToString();
                        if (numericUpDownmonth.Value < 10)
                            month = '0' + numericUpDownmonth.Value.ToString();
                        else
                            month = numericUpDownmonth.Value.ToString();
                        newrow["Birth_Date"] = numericUpDownyear.Value.ToString() + '/' + month + '/' + day;
                        newrow["Phone_Number"] = txtPhoneNum.Text;
                        newrow["Address"] = txtAddress.Text.TrimEnd().TrimStart();
                        newrow["Password"] = txtPassword.Text;
                        newrow["National_Code"] = txtNationalCode.Text;
                        newrow["Father_Name"] = txtFatherName.Text.TrimEnd().TrimStart();

                        dt.Rows.Add(newrow);

                        SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                        adapt.Update(dt);
                        dt.AcceptChanges();
                        cleartxtbox();
                        RefreshDatagridview(null);

                    }
                    else
                    {
                        DataRow newrow = dt.NewRow();
                        newrow["Personal_Id"] = txtPersonalId.Text;
                        newrow["First_Name"] = txtName.Text.TrimEnd().TrimStart();
                        newrow["Last_Name"] = txtLastName.Text.TrimEnd().TrimStart();
                        newrow["Degree_Education"] = comboBoxEx1.Text;
                        string day, month;
                        if (numericUpDownday.Value < 10)
                            day = '0' + numericUpDownday.Value.ToString();
                        else
                            day = numericUpDownday.Value.ToString();
                        if (numericUpDownmonth.Value < 10)
                            month = '0' + numericUpDownmonth.Value.ToString();
                        else
                            month = numericUpDownmonth.Value.ToString();
                        newrow["Birth_Date"] = numericUpDownyear.Value.ToString() + '/' + month + '/' + day;
                        newrow["Phone_Number"] = txtPhoneNum.Text;
                        newrow["Address"] = txtAddress.Text.TrimEnd().TrimStart();
                        newrow["Password"] = txtPassword.Text;
                        newrow["National_Code"] = txtNationalCode.Text;
                        newrow["Father_Name"] = txtFatherName.Text.TrimEnd().TrimStart();

                        dt.Rows.Add(newrow);

                        DataRow crow = getrow();
                        SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                        adapt = sqlb.DataAdapter;
                        crow.Delete();
                        adapt.Update(dt);
                        dt.AcceptChanges();
                        cleartxtbox();

                        edit = false;
                        RefreshDatagridview(null);
                    }
                }
                else if (resualt == DialogResult.Cancel)
                {
                    cleartxtbox();
                }

            }
            else
            {
                MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو", "!!خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private DataRow getrow()
        {
            if (bs.Current != null)
            {
                return ((DataRowView)bs.Current).Row;
            }
            else
            {
                return null;
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (getrow() != null)
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    DataRow crow = getrow();
                    SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                    adapt = sqlb.DataAdapter;
                    crow.Delete();
                    adapt.Update(dt);
                    dt.AcceptChanges();
                    RefreshDatagridview(null);
                    cleartxtbox();
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (getrow() != null)
            {
                SqlCommandBuilder sqlb1 = new SqlCommandBuilder(adapt);
                edit = true;

                DataRow newrow = getrow();
                txtPersonalId.Text = newrow["Personal_Id"].ToString();
                txtName.Text = newrow["First_Name"].ToString();
                txtLastName.Text = newrow["Last_Name"].ToString();
                comboBoxEx1.Text = newrow["Degree_Education"].ToString();
                string day, month, year;
                if (newrow["Birth_Date"].ToString()[4] == '/')
                {
                    year = newrow["Birth_Date"].ToString().Substring(0, 4);
                    month = newrow["Birth_Date"].ToString().Substring(5, 2);
                    day = newrow["Birth_Date"].ToString().Substring(8, 2);

                }
                else
                {
                    day = newrow["Birth_Date"].ToString().Substring(0, 2);
                    month = newrow["Birth_Date"].ToString().Substring(3, 2);
                    year = newrow["Birth_Date"].ToString().Substring(6, 4);

                }
                int Day = Convert.ToInt32(day);
                int Month = Convert.ToInt32(month);
                int Year = Convert.ToInt32(year);
                numericUpDownyear.Value = Year; numericUpDownmonth.Value = Month; numericUpDownday.Value = Day;

                txtPhoneNum.Text = newrow["Phone_Number"].ToString();
                txtAddress.Text = newrow["Address"].ToString();
                txtPassword.Text = newrow["Password"].ToString();
                txtNationalCode.Text = newrow["National_Code"].ToString();
                txtFatherName.Text = newrow["Father_Name"].ToString();
                panel1.Visible = true;
            }
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txt_search.Text == "جستجو : کد پرسنلی")
                txt_search.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "جستجو : کد پرسنلی";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txt_search.Text);
        }

        public void cleartxtbox()
        {
            txtPersonalId.Text = null; txtName.Text = null; txtLastName.Text = null;
            txtNationalCode.Text = null; txtFatherName.Text = null;
            txtPhoneNum.Text = null; txtPassword.Text = null; numericUpDownyear.Value =1300; numericUpDownmonth.Value =1; numericUpDownday.Value = 1;
            txtAddress.Text = null; comboBoxEx1.Text = null;
        }

        private void HeadAddProfessor_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'uniWebDataSet.MastersInfo' table. You can move, or remove it, as needed.
            this.mastersInfoTableAdapter.Fill(this.uniWebDataSet.MastersInfo);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            panel1.Visible = false;
            RefreshDatagridview(null);

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == false)
                panel1.Visible = true;
            else
                panel1.Visible = false;
        }

        private void numericUpDownday_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth.Value < 7)
                numericUpDownday.Maximum = 31;
            else if (numericUpDownmonth.Value == 12)
                numericUpDownday.Maximum = 29;
            else
                numericUpDownday.Maximum = 30;
        }

        private void numericUpDownmonth_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth.Value > 6 && numericUpDownday.Value > 30)
                numericUpDownday.Value = 30;
            if (numericUpDownmonth.Value > 11 && numericUpDownday.Value > 29)
                numericUpDownday.Value = 29;
            if (numericUpDownmonth.Value < 7 && numericUpDownday.Value == 30)
            {
                numericUpDownday_ValueChanged(sender, e);
                numericUpDownday.Value = 31;
            }
            if (numericUpDownmonth.Value < 12 && numericUpDownday.Value == 29)
            {
                numericUpDownday_ValueChanged(sender, e);
                numericUpDownday.Value = 30;
            }


        }

        private void HeadAddProfessor_FormClosing(object sender, FormClosingEventArgs e)
        {
            sqlcon.Close();
        }
    }












}


