﻿namespace UniversityManegmentAPP
{
    partial class HeadStudentLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeadStudentLogin));
            this.txtEnterId = new System.Windows.Forms.TextBox();
            this.btnenter = new System.Windows.Forms.Button();
            this.txtnameshow = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtEnterId
            // 
            this.txtEnterId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.txtEnterId.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtEnterId.ForeColor = System.Drawing.Color.White;
            this.txtEnterId.Location = new System.Drawing.Point(97, 39);
            this.txtEnterId.MaxLength = 13;
            this.txtEnterId.Name = "txtEnterId";
            this.txtEnterId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtEnterId.Size = new System.Drawing.Size(245, 33);
            this.txtEnterId.TabIndex = 0;
            this.txtEnterId.Text = "جستجو : کد دانشجویی";
            this.txtEnterId.Click += new System.EventHandler(this.txtEnterId_Click);
            this.txtEnterId.TextChanged += new System.EventHandler(this.txtEnterId_TextChanged);
            this.txtEnterId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnterId_KeyPress);
            this.txtEnterId.Leave += new System.EventHandler(this.txtEnterId_Leave);
            // 
            // btnenter
            // 
            this.btnenter.BackColor = System.Drawing.Color.CadetBlue;
            this.btnenter.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnenter.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnenter.Location = new System.Drawing.Point(97, 128);
            this.btnenter.Name = "btnenter";
            this.btnenter.Size = new System.Drawing.Size(112, 34);
            this.btnenter.TabIndex = 1;
            this.btnenter.Text = "ورود";
            this.btnenter.UseVisualStyleBackColor = false;
            this.btnenter.Click += new System.EventHandler(this.btnenter_Click);
            // 
            // txtnameshow
            // 
            this.txtnameshow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.txtnameshow.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtnameshow.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnameshow.ForeColor = System.Drawing.Color.White;
            this.txtnameshow.Location = new System.Drawing.Point(99, 91);
            this.txtnameshow.Name = "txtnameshow";
            this.txtnameshow.ReadOnly = true;
            this.txtnameshow.Size = new System.Drawing.Size(245, 22);
            this.txtnameshow.TabIndex = 2;
            this.txtnameshow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Crimson;
            this.button1.Font = new System.Drawing.Font("B Narm", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(232, 128);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 34);
            this.button1.TabIndex = 3;
            this.button1.Text = "انصراف";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HeadStudentLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(433, 204);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtnameshow);
            this.Controls.Add(this.btnenter);
            this.Controls.Add(this.txtEnterId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HeadStudentLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "دریافت شماره دانشجویی";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HeadStudentLogin_FormClosing);
            this.Load += new System.EventHandler(this.HeadStudentLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtEnterId;
        private System.Windows.Forms.Button btnenter;
        private System.Windows.Forms.TextBox txtnameshow;
        private System.Windows.Forms.Button button1;
    }
}