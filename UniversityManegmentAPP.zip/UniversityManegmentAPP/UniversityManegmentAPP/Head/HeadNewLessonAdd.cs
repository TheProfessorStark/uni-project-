﻿using DevComponents.Schedule.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityManegmentAPP
{
    public partial class addlesson : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        public SqlCommand cmd;
        public SqlDataReader dr;
        public bool edit = false;



        public addlesson()
        {
            InitializeComponent();
            customizeDesing();
        }

        private void customizeDesing()
        {
            panels1.Visible = false;

        }
        private void hideSubMenu()
        {
            if (panels1.Visible == true)
                panels1.Visible = false;


        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }

        private void btn_openpanl_Click(object sender, EventArgs e)
        {
            showSubMenu(panels1);
        }

        private void txtLDay_Click(object sender, EventArgs e)
        {

        }

        private void txtLessonTime_Click(object sender, EventArgs e)
        {

        }

        private void txtLessonName_Click(object sender, EventArgs e)
        {

        }

        private void txtUnitNumber_Click(object sender, EventArgs e)
        {

        }

        private void txtStartClass_Click(object sender, EventArgs e)
        {

        }

        private void txtFinalExamDate_Click(object sender, EventArgs e)
        {

        }

        private void txtLessonCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    comboBoxEx1_Click(sender, e);
                    comboBoxEx1.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtLDay_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {

                    numericUpDown1.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtLessonTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtLessonName_Click(sender, e);
                    txtLessonName.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtLessonName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtUnitNumber_Click(sender, e);
                    txtUnitNumber.Select();

                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtUnitNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {

                    numericUpDownyear.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtStartClass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {

                    numericUpDownyear2.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtFinalExamDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    pictureBox3_Click(sender, e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        public void RefreshDatagridview(string SearchText)
        {
            if (SearchText == null)
            {
                adapt = new SqlDataAdapter("select * from SubPresented", sqlcon);

                dt = new DataTable();

                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }
            else
            {
                adapt = new SqlDataAdapter("select * from SubPresented where Subject_ID like'" + SearchText + "%'", sqlcon);
                dt = new DataTable();

                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }

            if (dt.Rows.Count > 0)
                dataGridView1.Visible = true;
            else
                dataGridView1.Visible = false;
        }

        private void addlesonP_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet2.SubPresented' table. You can move, or remove it, as needed.
            this.subPresentedTableAdapter.Fill(this.uniWebDataSet2.SubPresented);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();

            RefreshDatagridview(null);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (txtLessonCode.Text != "" && comboBoxEx1.Text != "" && txtLessonName.Text.Trim() != "" && txtUnitNumber.Text != "" &&
                txtPresentId.Text != null)
            {
                
                
                
                    if (edit == false)
                    {
                        DataRow crow = getrow();
                        DataRow newrow = dt.NewRow();
                        newrow["Subject_ID"] = txtLessonCode.Text;
                        newrow["Subject_Name"] = txtLessonName.Text.TrimEnd().TrimStart();
                        newrow["Subject_Unit"] = Convert.ToInt32(txtUnitNumber.Text);
                        string day, month;
                        if (numericUpDownday.Value < 10)
                            day = '0' + numericUpDownday.Value.ToString();
                        else
                            day = numericUpDownday.Value.ToString();
                        if (numericUpDownmonth.Value < 10)
                            month = '0' + numericUpDownmonth.Value.ToString();
                        else
                            month = numericUpDownmonth.Value.ToString();
                        newrow["ClassStart_Date"] = numericUpDownyear.Value.ToString() + '/' + month + '/' + day;

                        string day2, month2;
                        if (numericUpDownday2.Value < 10)
                            day2 = '0' + numericUpDownday2.Value.ToString();
                        else
                            day2 = numericUpDownday2.Value.ToString();
                        if (numericUpDownmonth2.Value < 10)
                            month2 = '0' + numericUpDownmonth2.Value.ToString();
                        else
                            month2 = numericUpDownmonth2.Value.ToString();
                        newrow["Exam_Date"] = numericUpDownyear2.Value.ToString() + '/' + month2 + '/' + day2;

                        newrow["Day_Presentation"] = comboBoxEx1.Text;
                        string hour, minute;
                        if (numericUpDown1.Value < 10)
                            hour = '0' + numericUpDown1.Value.ToString();
                        else
                            hour = numericUpDown1.Value.ToString();
                        if (numericUpDown2.Value < 10)
                            minute = '0' + numericUpDown2.Value.ToString();
                        else
                            minute = numericUpDown2.Value.ToString();
                        newrow["Hour_Presentation"] = hour + ':' + minute;
                        newrow["Sub_Present_ID"] = txtPresentId.Text;



                        cmd = new SqlCommand("select * from SubPresented where Sub_Present_ID='" + txtPresentId.Text.ToString() + "'", sqlcon);
                        dr = cmd.ExecuteReader();
                        if (dr.Read())
                        {
                            MessageBox.Show("کد اراعه تکراری وارد کردی داداش", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            dr.Close();
                        }
                        else
                        {
                            DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                            if (resualt == DialogResult.OK)
                            {
                                dr.Close();
                                dt.Rows.Add(newrow);

                                SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                                adapt.Update(dt);
                                dt.AcceptChanges();
                                cleartxtbox();
                                RefreshDatagridview(null);
                            }
                            else if (resualt == DialogResult.Cancel)
                            {
                                txtSearch.Text = "";
                            }
                        }

                    }
                    else
                    {

                        DataRow newrow = dt.NewRow();
                        newrow["Subject_ID"] = Convert.ToInt64(txtLessonCode.Text);
                        newrow["Subject_Name"] = txtLessonName.Text.TrimEnd().TrimStart();
                        newrow["Subject_Unit"] = txtUnitNumber.Text;
                        string day, month;
                        if (numericUpDownday.Value < 10)
                            day = '0' + numericUpDownday.Value.ToString();
                        else
                            day = numericUpDownday.Value.ToString();
                        if (numericUpDownmonth.Value < 10)
                            month = '0' + numericUpDownmonth.Value.ToString();
                        else
                            month = numericUpDownmonth.Value.ToString();
                        newrow["ClassStart_Date"] = numericUpDownyear.Value.ToString() + '/' + month + '/' + day;

                        string day2, month2;
                        if (numericUpDownday2.Value < 10)
                            day2 = '0' + numericUpDownday2.Value.ToString();
                        else
                            day2 = numericUpDownday2.Value.ToString();
                        if (numericUpDownmonth2.Value < 10)
                            month2 = '0' + numericUpDownmonth2.Value.ToString();
                        else
                            month2 = numericUpDownmonth2.Value.ToString();
                        newrow["Exam_Date"] = numericUpDownyear2.Value.ToString() + '/' + month2 + '/' + day2;
                        newrow["Day_Presentation"] = comboBoxEx1.Text;
                        string hour, minute;
                        if (numericUpDown1.Value < 10)
                            hour = '0' + numericUpDown1.Value.ToString();
                        else
                            hour = numericUpDown1.Value.ToString();
                        if (numericUpDown2.Value < 10)
                            minute = '0' + numericUpDown2.Value.ToString();
                        else
                            minute = numericUpDown2.Value.ToString();
                        newrow["Hour_Presentation"] = hour + ':' + minute;
                        newrow["Sub_Present_ID"] = txtPresentId.Text;

                        DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                        if (resualt == DialogResult.OK)
                        {
                            dr.Close();
                            dt.Rows.Add(newrow);

                            DataRow crow = getrow();
                            SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                            adapt = sqlb.DataAdapter;
                            crow.Delete();
                            adapt.Update(dt);
                            dt.AcceptChanges();
                            cleartxtbox();

                            edit = false;
                            RefreshDatagridview(null);
                        }
                        else if (resualt == DialogResult.Cancel)
                        {
                            txtSearch.Text = "";
                        }
                    }
            }
            else
            {
                MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو ", "!!خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataRow getrow()
        {
            if (bs.Current != null)
            {
                return ((DataRowView)bs.Current).Row;
            }
            else
            {
                return null;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (getrow() != null)
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    DataRow crow = getrow();
                    SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                    adapt = sqlb.DataAdapter;
                    crow.Delete();
                    adapt.Update(dt);
                    dt.AcceptChanges();
                    RefreshDatagridview(null);
                    cleartxtbox();
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (getrow() != null)
            {
                SqlCommandBuilder sqlb1 = new SqlCommandBuilder(adapt);
                edit = true;

                DataRow crow = getrow();
                txtLessonCode.Text = crow["Subject_ID"].ToString();
                txtLessonName.Text = crow["Subject_Name"].ToString();
                txtUnitNumber.Text = crow["Subject_Unit"].ToString();
                string day, month, year;
                if (crow["ClassStart_Date"].ToString()[4] == '/')
                {
                    year = crow["ClassStart_Date"].ToString().Substring(0, 4);
                    month = crow["ClassStart_Date"].ToString().Substring(5, 2);
                    day = crow["ClassStart_Date"].ToString().Substring(8, 2);

                }
                else
                {
                    day = crow["ClassStart_Date"].ToString().Substring(0, 2);
                    month = crow["ClassStart_Date"].ToString().Substring(3, 2);
                    year = crow["ClassStart_Date"].ToString().Substring(6, 4);

                }
                int Day = Convert.ToInt32(day);
                int Month = Convert.ToInt32(month);
                int Year = Convert.ToInt32(year);
                numericUpDownyear.Value = Year; numericUpDownmonth.Value = Month; numericUpDownday.Value = Day;

                string day2, month2, year2;

                if (crow["Exam_Date"].ToString()[4] == '/')
                {
                    year2 = crow["Exam_Date"].ToString().Substring(0, 4);
                    month2 = crow["Exam_Date"].ToString().Substring(5, 2);
                    day2 = crow["Exam_Date"].ToString().Substring(8, 2);

                }
                else
                {
                    day2 = crow["Exam_Date"].ToString().Substring(0, 2);
                    month2 = crow["Exam_Date"].ToString().Substring(3, 2);
                    year2 = crow["Exam_Date"].ToString().Substring(6, 4);

                }
                int Day2 = Convert.ToInt32(day2);
                int Month2 = Convert.ToInt32(month2);
                int Year2 = Convert.ToInt32(year2);
                numericUpDownyear2.Value = Year2; numericUpDownmonth2.Value = Month2; numericUpDownday2.Value = Day2;


                comboBoxEx1.Text = crow["Day_Presentation"].ToString();
                numericUpDown1.Value = Convert.ToInt32(crow["Hour_Presentation"].ToString().Substring(0, 2));
                numericUpDown2.Value = Convert.ToInt32(crow["Hour_Presentation"].ToString().Substring(3, 2));
                txtPresentId.Text = crow["Sub_Present_ID"].ToString();
            }

        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == "جستجو: کد درس")
                txtSearch.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "جستجو: کد درس";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txtSearch.Text);
        }

        public void cleartxtbox()
        {
            numericUpDownyear2.Value = 1300; numericUpDownmonth2.Value = 1; numericUpDownday2.Value = 1;
            comboBoxEx1.Text = null; txtLessonCode.Text = null;
            txtLessonName.Text = null; numericUpDownyear.Value = 1300; numericUpDownmonth.Value = 1; numericUpDownday.Value = 1;
            txtUnitNumber.Text = null; txtPresentId.Text = null;
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
        }

        private void txtPresentId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    comboBoxEx1_Click(sender, e);
                    comboBoxEx1.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void comboBoxEx1_Click(object sender, EventArgs e)
        {

        }
        private void numericUpDownday_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth.Value < 7)
                numericUpDownday.Maximum = 31;
            else if (numericUpDownmonth.Value == 12)
                numericUpDownday.Maximum = 29;
            else
                numericUpDownday.Maximum = 30;
        }

        private void numericUpDownmonth_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth.Value > 6 && numericUpDownday.Value > 30)
                numericUpDownday.Value = 30;
            if (numericUpDownmonth.Value > 11 && numericUpDownday.Value > 29)
                numericUpDownday.Value = 29;
            if (numericUpDownmonth.Value < 7 && numericUpDownday.Value == 30)
            {
                numericUpDownday_ValueChanged(sender, e);
                numericUpDownday.Value = 31;
            }
            if (numericUpDownmonth.Value < 12 && numericUpDownday.Value == 29)
            {
                numericUpDownday_ValueChanged(sender, e);
                numericUpDownday.Value = 30;
            }


        }

        private void numericUpDownmonth2_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth2.Value > 6 && numericUpDownday2.Value > 30)
                numericUpDownday2.Value = 30;
            if (numericUpDownmonth2.Value > 11 && numericUpDownday2.Value > 29)
                numericUpDownday2.Value = 29;
            if (numericUpDownmonth2.Value < 7 && numericUpDownday2.Value == 30)
            {
                numericUpDownday2_ValueChanged(sender, e);
                numericUpDownday2.Value = 31;
            }
            if (numericUpDownmonth2.Value < 12 && numericUpDownday2.Value == 29)
            {
                numericUpDownday2_ValueChanged(sender, e);
                numericUpDownday2.Value = 30;
            }


        }

        private void numericUpDownday2_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth2.Value < 7)
                numericUpDownday2.Maximum = 31;
            else if (numericUpDownmonth2.Value == 12)
                numericUpDownday2.Maximum = 29;
            else
                numericUpDownday2.Maximum = 30;
        }

        private void addlesson_FormClosing(object sender, FormClosingEventArgs e)
        {
            sqlcon.Close();
        }
    }
}
