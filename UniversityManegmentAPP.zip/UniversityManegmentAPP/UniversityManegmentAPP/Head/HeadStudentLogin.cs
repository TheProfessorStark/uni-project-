﻿using DevComponents.DotNetBar.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UniversityManegmentAPP;

namespace UniversityManegmentAPP
{
    public partial class HeadStudentLogin : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public SqlDataAdapter adapt2;
        public DataTable dt;
        public DataTable dt2;
        public BindingSource bs;
        public BindingSource bs2;
        public SqlCommand cmd;
        public SqlDataReader dr;

        public HeadStudentLogin()
        {
            InitializeComponent();
        }
        private void HeadStudentLogin_Load(object sender, EventArgs e)
        {
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
        }

        private void btnenter_Click(object sender, EventArgs e)
        {
            if (txtEnterId.Text != "جستجو : کد دانشجویی" && txtEnterId.Text != "")
            {
                SqlCommand cmd2 = new SqlCommand("select * from StudentInfo where ID='" + txtEnterId.Text + "'", sqlcon);
                SqlDataReader dr2 = cmd2.ExecuteReader();
                if (dr2.Read())
                {

                    dr2.Close();
                    Class1.CurrentId = txtEnterId.Text;
                    Class1.CurrentName = txtnameshow.Text;
                    this.Close();
                }
                else
                {
                    dr2.Close();
                    MessageBox.Show("شماره دانشجوییو درست وارد کن مسخره!!", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEnterId.Text = null;
                    txtEnterId.Select();
                }
            }
            else
            {
                MessageBox.Show("ابتدا شماره دانشجویی را وارد کنید", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEnterId.Select();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class1.CurrentId = "0";
            this.Close();
        }

        private void txtEnterId_TextChanged(object sender, EventArgs e)
        {
            if (txtEnterId.Text != "جستجو : کد دانشجویی" && txtEnterId.Text != "")
            {
                SqlCommand cmd2 = new SqlCommand("select * from StudentInfo where ID='" + txtEnterId.Text + "'", sqlcon);
                SqlDataReader dr2 = cmd2.ExecuteReader();
                if (dr2.Read())
                {
                    txtnameshow.Text = dr2["First_Name"] + " " + dr2["Last_Name"];
                    dr2.Close();
                }
                else
                {
                    dr2.Close();
                    txtnameshow.Text = null;
                }
            }

        }

        private void txtEnterId_Leave(object sender, EventArgs e)
        {

            if (txtEnterId.Text == "")
            {
                txtEnterId.Text = "جستجو : کد دانشجویی";

            }
        }

        private void txtEnterId_Click(object sender, EventArgs e)
        {
            if (txtEnterId.Text == "جستجو : کد دانشجویی")
                txtEnterId.Text = null;
        }

        private void txtEnterId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnenter_Click(sender,e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void HeadStudentLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            sqlcon.Close();
        }
    }
}
