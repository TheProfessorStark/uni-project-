﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using UniversityManegmentAPP;

namespace UniversityManegmentAPP
{
    public partial class Headstudentlesson : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public SqlDataAdapter adapt2;
        public DataTable dt;
        public DataTable dt2;
        public BindingSource bs;
        public BindingSource bs2;
        public SqlCommand cmd;
        public SqlDataReader dr;

        public Headstudentlesson()
        {
            InitializeComponent();
            customizeDesing();
        }

        private void customizeDesing()
        {
            panel2.Visible = false;

        }
        private void hideSubMenu()
        {
            if (panel2.Visible == true)
                panel2.Visible = false;


        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }

        private DataRow getrow(int a)
        {
            if (a == 1)
            {
                if (bs.Current != null)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
            if (a == 2)
            {
                if (bs2.Current != null)
                {
                    return ((DataRowView)bs2.Current).Row;
                }
                else
                {
                    return null;
                }
            }
            else
                return null;
        }

        public void RefreshDatagridview(string SearchText, string StudentId)
        {
            if (SearchText != null)
            {
                if (SearchText != "جستجو : کد درس")
                {
                    adapt2 = new SqlDataAdapter("select * from TeacherSubSelected where Subject_ID like'" + SearchText + "%'", sqlcon);
                    dt2 = new DataTable();
                    adapt2.Fill(dt2);
                    bs2 = new BindingSource();
                    bs2.DataSource = dt2;
                    dataGridView2.DataSource = bs2;
                }
                else
                {
                    adapt2 = new SqlDataAdapter("select * from TeacherSubSelected", sqlcon);
                    dt2 = new DataTable();
                    adapt2.Fill(dt2);
                    bs2 = new BindingSource();
                    bs2.DataSource = dt2;
                    dataGridView2.DataSource = bs2;
                }
            }
            if (StudentId != null)
            {
                if (StudentId != "جستجو : کد دانشجویی")
                {
                    adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id ='" + StudentId + "'", sqlcon);
                    dt = new DataTable();
                    adapt.Fill(dt);
                    bs = new BindingSource();
                    bs.DataSource = dt;
                    dataGridView1.DataSource = bs;
                }
                else
                {
                    adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id ='" + null + "'", sqlcon);
                    dt = new DataTable();
                    adapt.Fill(dt);
                    bs = new BindingSource();
                    bs.DataSource = dt;
                    dataGridView1.DataSource = bs;
                }

            }
            if (dt.Rows.Count > 0)
            {
                dataGridView1.Visible = true; 
                label1.Text = ": دروس انتخاب شده";   
            }

            else
            {
                dataGridView1.Visible = false;
                label1.Text = "درسی برای این دانشجو انتخاب نشده است";  
            }

            if (dt2.Rows.Count > 0)
            {
                dataGridView2.Visible = true;
                label2.Visible = true;
            }

            else
            {
                dataGridView2.Visible = false;
                label2.Visible = false;
            }

        }

        private void DeleteSelectedLesson_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet3.TeacherSubSelected' table. You can move, or remove it, as needed.
            this.teacherSubSelectedTableAdapter.Fill(this.uniWebDataSet3.TeacherSubSelected);
            // TODO: This line of code loads data into the 'uniWebDataSet5.StudentSubSelected' table. You can move, or remove it, as needed.
            //this.studentSubSelectedTableAdapter.Fill(this.uniWebDataSet5.StudentSubSelected);
            // TODO: This line of code loads data into the 'uniWebDataSet4.SubPresented' table. You can move, or remove it, as needed.
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            RefreshDatagridview(txtSearch.Text, Class1.CurrentId.ToString());
            label4.Text = Class1.CurrentName;


        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == "جستجو : کد درس")
                txtSearch.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "جستجو : کد درس";
                RefreshDatagridview(txtSearch.Text, Class1.CurrentId.ToString());
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txtSearch.Text, Class1.CurrentId.ToString());
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DataRow crow = getrow(1);
            if (crow != null)
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                    adapt = sqlb.DataAdapter;
                    crow.Delete();
                    adapt.Update(dt);
                    dt.AcceptChanges();
                    RefreshDatagridview(txtSearch.Text, Class1.CurrentId.ToString());
                }
            }
            else
                MessageBox.Show("ابتدا شماره دانشجویی را وارد کنید", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            DataRow crow = getrow(2);
            DataRow newrow = dt.NewRow();

            newrow["Student_Id"] = Class1.CurrentId;
            newrow["Subject_Id"] = crow["Subject_ID"].ToString();
            newrow["Subject_Name"] = crow["Subject_Name"].ToString();
            newrow["subject_Unit"] = crow["Subject_Unit"].ToString();
            newrow["Subject_Teacher"] = crow["Teacher_Presentation"].ToString();
            newrow["Sub_Present_ID"] = crow["Present_ID"].ToString();
            newrow["Teacher_Present_ID"] = crow["Teacher_Present_ID"].ToString();
            newrow["NV"] = Class1.CurrentId + "/" + crow["Subject_ID"].ToString();

            cmd = new SqlCommand("select * from StudentSubSelected where NV='" + Class1.CurrentId + "/" + crow["Subject_ID"].ToString() + "'", sqlcon);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("مرض داری 2 بار اد می کنی؟", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dr.Close();
            }
            else
            {
                dr.Close();
                dt.Rows.Add(newrow);

                SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                adapt.Update(dt);
                dt.AcceptChanges();

                RefreshDatagridview(txtSearch.Text, Class1.CurrentId.ToString());
            }


           
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {

            if (panel2.Visible == true)
                panel2.Visible = false;
            else
                panel2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string currentid = Class1.CurrentId;
            new HeadStudentLogin().ShowDialog();
            if (currentid != Class1.CurrentId)
                DeleteSelectedLesson_Load(sender, e);
        }

        private void Headstudentlesson_FormClosing(object sender, FormClosingEventArgs e)
        {
            sqlcon.Close();
        }
    }
}
