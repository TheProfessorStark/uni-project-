﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityManegmentAPP
{
    internal class Class1
    {
        public static string CurrentId;
        public static string CurrentName;
    }
}
